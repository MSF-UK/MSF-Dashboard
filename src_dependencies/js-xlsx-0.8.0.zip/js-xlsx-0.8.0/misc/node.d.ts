declare var require: {
  (id: string): any;
}

declare var process: {
  argv: string[];
  exit(status: number): void;
}
